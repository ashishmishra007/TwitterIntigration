package com.ashish.twitterutils;

public class BitlyURLShortner 
{
  private static final String APIKEY = "Your Ket";
  private static final String UserName = "Your username";

  public static String getShortenedUrl(String url) 
  {
	   if(url!=null && url.trim().length()>0)
	   {
           BitlyAndroid bitlyAndroid = new BitlyAndroid(UserName, APIKEY);
           try 
           {
			   url = bitlyAndroid.getShortUrl(url);
		   } 
           catch (Exception e) 
           {
        	   if(e!=null)
			   e.printStackTrace();
			  
			   url="";
		    }
           
		   return url;   
	   }
	   else
	   return "";
   }
}
