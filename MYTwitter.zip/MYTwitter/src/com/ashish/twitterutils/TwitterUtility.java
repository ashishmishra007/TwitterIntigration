package com.ashish.twitterutils;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.regex.Pattern;

import org.json.JSONObject;

import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.http.AccessToken;
import twitter4j.http.OAuthAuthorization;
import twitter4j.util.ImageUpload;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ashish.twitterutils.TwitterApp.TwDialogListener;
import com.example.hbtwitter.R;

public class TwitterUtility
{
	private Activity activity;
	private static TwitterApp mTwitter;

	private final String twitter_consumer_key;
	private final String twitter_secret_key;
	private String twitpic_api_key;

    private ProgressDialog mProgress;

	private String testFilePath = "";
	private String tweetMessage = "";
	private String filePath = "";

	private int METHOD = -1;
	private final int TWEET = 0, UPLOAD = 1,LOGIN = 2;
	
	private String imageUrl="";

	private TwitterCallbackListener twitterCallbackListener;
	private boolean showTwitterDialog=false;
	
	    //private static final String my_twitter_consumer_key = "E92dbfv7BIHGNUdrWWEmA";
		//private static final String my_twitter_secret_key = "8DxuiEzUqgUcfi5NhynGMBy9cRWfzRSPGXq88ghwa4";
	    //private static final String my_tweet_pic_key = "0e4251fb8225994158ea74b08725b123";	
		
	/**
	 * @param a
	 *            context of Activity in which you want to use this Utility
	 * @param twitter_consumer_key
	 *            your twiiter application's consumer key
	 * @param twitter_secret_key
	 *            your twiiter application's secret key
	 */
	public TwitterUtility(Context a, String twitter_consumer_key,
			String twitter_secret_key) {
		this.twitter_consumer_key = twitter_consumer_key;
		this.twitter_secret_key = twitter_secret_key;

		activity = (Activity) a;

		mProgress = new ProgressDialog(activity);
		mProgress.setMessage("Updating Status...");
		mProgress.setTitle("Please wait");
		
		mTwitter = new TwitterApp(activity, twitter_consumer_key,
				twitter_secret_key);
		mTwitter.setListener(mTwLoginDialogListener);
	}

	private boolean autheticateData() {
		boolean success = false;

		if (isNetworkAvailable()) {
			try {
				success = mTwitter.hasAccessToken();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return success;
	}

	public void loginTwitter(TwitterCallbackListener twitterCallbackListener) 
	{
		this.twitterCallbackListener = twitterCallbackListener;
		
		if(!autheticateData())
		{
			METHOD = LOGIN;
			mTwitter.authorize();
		}
		else if(twitterCallbackListener!=null)
		twitterCallbackListener.twitterCallback(false, "You are already logged in");	
	}

	/**
	 * @return <b>true</b> if you logout successfully <br/>
	 *         <b>false</b> if session is expired or you are not logged in <br/>
	 */
	public boolean logoutTwitter() 
	{
		boolean success = true;

		try {
			if (mTwitter.hasAccessToken()) {
				try {
					mTwitter.resetAccessToken();
				} catch (Exception e) {
					e.printStackTrace();
					success = false;
				}
			} else
				success = false;
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		}

		return success;
	}

	
	/**
	 * @param message
	 * @param twitterCallbackListener
	 */
	public void share(String message,boolean showTwitterDialog)
	{
		this.showTwitterDialog = showTwitterDialog;
		
		METHOD = TWEET;
		tweetMessage = message;

		if (autheticateData())
			tweet();
		else
			 mTwitter.authorize(); // login	
	}
	
	/**
	 * @param url
	 * @param message
	 * @param twitterCallbackListener
	 */
	public void share(String url,String message,boolean showTwitterDialog)
	{
		this.showTwitterDialog = showTwitterDialog;
		METHOD = TWEET;
		tweetMessage = message;
		new BiltyUrlShortnerTask().execute(new String[]{url});
	}
	
	
	/**
	 * @param imageUrl
	 *            url of the image which you want to upload to your account
	 * @param tweetPicAPIkey
	 *            your TwitPick API key
	 * @throws Exception
	 */
	public void uploadPhoto(String imageUrl, String tweetPicAPIkey,boolean showTwitterDialog)
	{
		this.showTwitterDialog = showTwitterDialog;
		METHOD = UPLOAD;
		this.imageUrl = imageUrl;
		twitpic_api_key = tweetPicAPIkey;

		if (autheticateData())
			upload();
		else
			mTwitter.authorize(); // login
	}

	/**
	 * @param path
	 *            path of the image which you want to upload
	 * @param tweetPicAPIkey
	 *            your TwitPick API key
	 * @throws Exception
	 */
	public void uploadPhoto(File path, String tweetPicAPIkey,boolean showTwitterDialog)
	{
		this.showTwitterDialog = showTwitterDialog;
		METHOD = UPLOAD;
		filePath = path.getAbsolutePath();
		twitpic_api_key = tweetPicAPIkey;

		if (autheticateData())
			upload();
		else
			mTwitter.authorize(); // login
	}

	/**
	 * @param imageUrl
	 *            url of the image which you want to upload to your account
	 * @param tweetPicAPIkey
	 *            your TwitPick API key
	 * @param message
	 *            message to tweet
	 * @throws Exception
	 */
	public void uploadAndTweet(String imageUrl, String tweetPicAPIkey,
			String message,boolean showTwitterDialog)
	{
		this.showTwitterDialog = showTwitterDialog;
		this.tweetMessage = message;
		uploadPhoto(imageUrl, tweetPicAPIkey,showTwitterDialog);
	}

	/**
	 * @param filePath
	 *            path of the image which you want to upload
	 * @param tweetPicAPIkey
	 *            your TwitPick API key
	 * @param message
	 *            message to tweet
	 * @throws Exception
	 */
	public void uploadAndTweet(File file, String tweetPicAPIkey,
			String message,boolean showTwitterDialog)
			{
				this.showTwitterDialog = showTwitterDialog;
		this.tweetMessage = message;
		uploadPhoto(filePath, tweetPicAPIkey,showTwitterDialog);
	}

	private final TwDialogListener mTwLoginDialogListener = new TwDialogListener() {
		@Override
		public void onComplete(String value) {
			switch (METHOD) {
			case TWEET:
				tweet();
				break;

			case UPLOAD:
				upload();
				break;
				
			case LOGIN:
				if(twitterCallbackListener!=null)
				twitterCallbackListener.twitterCallback(true, "Logged in as "+mTwitter.getUsername());	
				break;	
			}
		}

		@Override
		public void onError(String value) 
		{
		   if(twitterCallbackListener!=null && METHOD==LOGIN)
			   twitterCallbackListener.twitterCallback(true, value);	  
		}
	};

	private void tweet() 
	{
		if(showTwitterDialog)
		{
		final AlertDialog.Builder alertdialog = new AlertDialog.Builder(
				activity);

		final View view = activity.getLayoutInflater().inflate(
				R.layout.twitter_share, null);

		// alertdialog.setView(view);

		final AlertDialog dialog = alertdialog.create();

		// Dialog dialog = new Dialog(activity);
		dialog.setView(view, 0, 0, 0, 0);
		final TextView txt_remaining = (TextView) view
				.findViewById(R.id.text_remain);

		int len = 140 - tweetMessage.length();

		if (tweetMessage != null)
			txt_remaining.setText("" + len);
		else
			txt_remaining.setText(140);

		final EditText et_message = (EditText) view
				.findViewById(R.id.et_message);
		et_message.setText(tweetMessage);
		et_message.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {

			}

			@Override
			public void afterTextChanged(Editable s) {
				int len = 140 - s.length();
				TextView txt = (TextView) view.findViewById(R.id.text_remain);
				txt.setText("" + len);
			}
		});

		Button cancel = (Button) view.findViewById(R.id.cancel);
		cancel.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		Button send = (Button) view.findViewById(R.id.send_to_tweet);
		send.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				tweetMessage = et_message.getText().toString();
				dialog.dismiss();
				mProgress.show();
				new RetreiveFeedTask().execute();
			}
		});

		dialog.show();
		}
		else
		{
			mProgress.show();
			new RetreiveFeedTask().execute();
		}
	}

	class RetreiveFeedTask extends AsyncTask<String, Void, String> {

		protected String doInBackground(String... urls) 
		{
			String feed = "Your Tweet was posted!";
			try {

				if (tweetMessage == null) {
					feed = "Your Tweet was not posted!";
				} 
				else if (tweetMessage.equals("")) 
				{
					feed = "Your Tweet was not posted!";
				}
				else
				mTwitter.updateStatus(tweetMessage);
			} catch (Exception e) {
				feed = e.getMessage();
				if (feed == null)
					feed = "Your Tweet was not posted!";
				else {
					Pattern p1 = Pattern.compile("[{}]");
					String s[] = p1.split(feed);
					for (String str : s) {
						String pattern = "\"" + "error" + "\"" + ":";

						if (str.contains(pattern)) {
							str = "{" + str + "}";

							try {
								JSONObject jsonObject = new JSONObject(str);
								if (jsonObject != null)
									if (jsonObject.has("error")) {
										feed = jsonObject.getString("error");
										feed = feed.trim();
									}
							} catch (Exception e1) {
								e1.printStackTrace();
							}
						}
					}
				}
			}

			return feed;

		}

		protected void onPostExecute(String feed) 
		{
			mProgress.dismiss();
			showAlert(feed);
		}
	}

	private void showAlert(String message) {
		AlertDialog.Builder alBuilder = new AlertDialog.Builder(activity);
		alBuilder.setTitle("Alert");
		alBuilder.setMessage(message);
		alBuilder.setPositiveButton("OK", null);
		alBuilder.show();
	}

	private void upload() 
	{
		 if(showTwitterDialog)
		 mProgress.setMessage("Fetching image...");

		 mProgress.show();
		 
		if (filePath.equals("")) 
		{
			Bitmap bitmap = getImageFromUrl(imageUrl);
			testFilePath = System.currentTimeMillis() + ".png";
			filePath = storeImageInSdCard(bitmap);
		}
		new UploaderTask().execute();
	}

	private String storeImageInSdCard(Bitmap bitmap) {
		String path = "";
		try {
			if (bitmap != null) {
				testFilePath = Environment.getExternalStorageDirectory()
						.toString() + "/" + testFilePath;

				File file = new File(testFilePath);
				if (file.exists())
					file.delete();

				byte[] bytes = convertBitmapToByteArray(bitmap);

				if (bytes != null) {
					OutputStream stream = new FileOutputStream(testFilePath);
					stream.write(bytes);
					stream.flush();
					stream.close();
					path = testFilePath;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			path = "";
		}
		return path;
	}

	private byte[] convertBitmapToByteArray(Bitmap bitmap) {
		if (bitmap == null) {
			return null;
		} else {
			byte[] b = null;
			try {
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				bitmap.compress(CompressFormat.PNG, 0, byteArrayOutputStream);
				b = byteArrayOutputStream.toByteArray();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return b;
		}
	}

	private Bitmap getImageFromUrl(String imageUrl) {
		Bitmap bitmap = null;

		if (imageUrl == null) {
			return bitmap;
		} else if (imageUrl.equals("") || (!imageUrl.startsWith("http"))) {
			return bitmap;
		} else if (!isNetworkAvailable()) {
			return bitmap;
		} else {
			try {

				imageUrl = imageUrl.trim();
				InputStream i = null;
				BufferedInputStream bis = null;
				ByteArrayOutputStream out = null;

				URL m = new URL(imageUrl);
				i = (InputStream) m.getContent();
				bis = new BufferedInputStream(i, 1024 * 8);
				out = new ByteArrayOutputStream();
				int len = 0;
				byte[] buffer = new byte[4096];
				while ((len = bis.read(buffer)) != -1) {
					out.write(buffer, 0, len);
				}
				out.close();
				bis.close();

				byte[] data = out.toByteArray();
				bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return bitmap;
		}
	}

	private boolean isNetworkAvailable() {
		boolean connection = false;
		try {
			ConnectivityManager cm = (ConnectivityManager) activity
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			if(cm!=null)
			{
			NetworkInfo net_info = cm.getActiveNetworkInfo();
			if (net_info != null && net_info.isConnected())
				connection = true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	} 

	public interface TwitterCallbackListener
	{
		public void twitterCallback(boolean success,String response);
	}

	private class UploaderTask extends AsyncTask<String, String, String>
	{
		@Override
		protected String doInBackground(String... params) 
		{
			try {
				File file = new File(filePath);

				TwitterSession twitterSession = new TwitterSession(activity);
				AccessToken accessToken = twitterSession.getAccessToken();

				Configuration conf = new ConfigurationBuilder()
						.setOAuthConsumerKey(twitter_consumer_key)
						.setOAuthConsumerSecret(twitter_secret_key)
						.setOAuthAccessToken(accessToken.getToken())
						.setOAuthAccessTokenSecret(accessToken.getTokenSecret())
						.build();

				OAuthAuthorization auth = new OAuthAuthorization(conf,
						conf.getOAuthConsumerKey(), conf.getOAuthConsumerSecret(),
						new AccessToken(conf.getOAuthAccessToken(),
								conf.getOAuthAccessTokenSecret()));

				ImageUpload imageUpload = ImageUpload.getTwitpicUploader(
						twitpic_api_key, auth);

				tweetMessage += " " + imageUpload.upload(file);

				Log.d("TEST", "Image uploaded, Twitpic url is " + tweetMessage);
				
				

			} catch (Exception e) {
				e.printStackTrace();
			}

			try {
				File f = new File(testFilePath);
				if (f.exists())
					f.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return tweetMessage;
		}
		
		@Override
		protected void onPostExecute(String result) 
		{
			super.onPostExecute(result);
		    if(showTwitterDialog)
		    {
		    	mProgress.dismiss();
		    	mProgress.setMessage("Updating Status...");
		    	tweet();		
		    }
		    else
		    {
		    	new RetreiveFeedTask().execute();
		    }
		}
	}

	private class BiltyUrlShortnerTask extends AsyncTask<String, Integer,String>
	{

		@Override
		protected String doInBackground(String... params) 
		{
			String url = params[0];
			String shoertenedUrl = BitlyURLShortner.getShortenedUrl(url);
			tweetMessage += shoertenedUrl; 
			return null;
		}
		
		@Override
		protected void onPostExecute(String result) 
		{
			super.onPostExecute(result);

			if (autheticateData())
				tweet();
			else
				 mTwitter.authorize(); // login	
		}
	}
	
}
