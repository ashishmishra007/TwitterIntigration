package com.example.Ashishtwitter;

import android.app.Activity;
import android.os.Bundle;

import com.ashish.twitterutils.TwitterUtility;
import com.example.hbtwitter.R;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        TwitterUtility twitterUtility = new TwitterUtility(this,"twitter_consumer_key","twitter_secret_key");
        twitterUtility.share("adas", true);
        //twitterUtility.share("http://stackoverflow.com/questions/12330329/how-to-access-network-provider-latitude-and-longitude-value-with-4-0-or-4-0", "hello!", false);
        //twitterUtility.share("test tweet from android on "+new Date().toLocaleString(), true);
//        boolean success = twitterUtility.logoutTwitter();
//        twitterUtility.loginTwitter(new TwitterCallbackListener()
//        {
//			
//			@Override
//			public void twitterCallback(boolean success, String response) 
//			{
//			   Log.d("TEST", response);	
//			}
//		});
     
        // Check Date issue and send the response accordingly
     
        // check getUsername method
        
    }
}
